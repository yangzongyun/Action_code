#coding=utf-8
import os 

os.system('play ./voices/1个.mp3')
os.system('play ./voices/2个.mp3')
os.system('play ./voices/3个.mp3')
os.system('play ./voices/任务完成.mp3')