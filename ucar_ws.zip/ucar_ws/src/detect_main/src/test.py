#!/usr/bin/env python2
import os
os.system("play ~/ucar_ws/src/mp3/youhailaji.mp3")