var searchData=
[
  ['offset_5fangle',['offset_angle',['../structoffset__angle.html',1,'']]],
  ['outputwriter',['OutputWriter',['../class_c_simple_ini_templ_1_1_output_writer.html',1,'CSimpleIniTempl']]]
];
